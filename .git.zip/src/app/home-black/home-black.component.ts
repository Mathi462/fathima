import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-black',
  templateUrl: './home-black.component.html',
  styleUrls: ['./home-black.component.css']
})
export class HomeBlackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;

}
