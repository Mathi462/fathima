import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery2',
  templateUrl: './gallery2.component.html',
  styleUrls: ['./gallery2.component.css']
})
export class Gallery2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;

}
