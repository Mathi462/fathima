import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aminities1',
  templateUrl: './aminities1.component.html',
  styleUrls: ['./aminities1.component.css']
})
export class Aminities1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;
}
