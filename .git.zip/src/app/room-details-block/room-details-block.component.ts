import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-room-details-block',
  templateUrl: './room-details-block.component.html',
  styleUrls: ['./room-details-block.component.css']
})
export class RoomDetailsBlockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;
}
