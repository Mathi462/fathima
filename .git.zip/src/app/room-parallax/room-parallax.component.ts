import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-room-parallax',
  templateUrl: './room-parallax.component.html',
  styleUrls: ['./room-parallax.component.css']
})
export class RoomParallaxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;
}
