import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-activity',
  templateUrl: './db-activity.component.html',
  styleUrls: ['./db-activity.component.css']
})
export class DbActivityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;
}
