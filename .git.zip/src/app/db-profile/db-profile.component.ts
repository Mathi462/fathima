import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-profile',
  templateUrl: './db-profile.component.html',
  styleUrls: ['./db-profile.component.css']
})
export class DbProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;
 

}
