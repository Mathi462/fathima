import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-event',
  templateUrl: './db-event.component.html',
  styleUrls: ['./db-event.component.css']
})
export class DbEventComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;

}
