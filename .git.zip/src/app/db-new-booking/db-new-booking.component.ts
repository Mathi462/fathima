import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-new-booking',
  templateUrl: './db-new-booking.component.html',
  styleUrls: ['./db-new-booking.component.css']
})
export class DbNewBookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;
}
