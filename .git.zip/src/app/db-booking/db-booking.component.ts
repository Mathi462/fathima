import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-booking',
  templateUrl: './db-booking.component.html',
  styleUrls: ['./db-booking.component.css']
})
export class DbBookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  name:any;
  name1:any;
  name3:any;
}
